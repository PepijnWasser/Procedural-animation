﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandSolver : MonoBehaviour
{

    Vector3 originalPos;
    float timer;

    public string armSide;
    public float speed;
    public float deltaX;
    public float deltaY;

    public GameObject target;
    public GameObject endOfBone;
    public int maxDistance;

    bool lastGrabbing = false;
    bool currentGrabbing = false;
    bool isLerping;

    Vector3 startPosition;
    float localTimer = 0;

    // Start is called before the first frame update
    void Start()
    {
        originalPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        lastGrabbing = currentGrabbing;
        if(Vector3.Distance(target.transform.position, endOfBone.transform.position) < maxDistance && Vector3.Distance(target.transform.position, new Vector3(0, 2.5f, 0)) > 2.5f)
        {
            HandleGrabbing();
        }
        else
        {
            currentGrabbing = false;

            if(lastGrabbing == true && currentGrabbing == false)
            {
                isLerping = true;
                startPosition = endOfBone.transform.position;

                localTimer = 0;
            }
            if (isLerping)
            {
                HandleArmReset();
            }
            else
            {
                HandleArmAnimation();
            }
        }
        timer += Time.deltaTime * speed;
    }

    void HandleArmReset()
    {
        if (localTimer > 1)
        {
            localTimer = 1;
        }
        transform.position = Vector3.Lerp(startPosition, originalPos, localTimer);
        localTimer += Time.deltaTime;
        if (Vector3.Distance(originalPos, transform.position) < 0.1f)
        {
            if (Mathf.Sin(timer) > -0.1 && Mathf.Sin(timer) < 0.1)
            {
                isLerping = false;
            }
        }
    }

    void HandleArmAnimation()
    {
        if (armSide == "left")
        {
            transform.localPosition = originalPos + new Vector3(Mathf.Sin(timer) * deltaX, 0, Mathf.Sin(timer) * deltaY);
        }
        else if (armSide == "right")
        {
            transform.localPosition = originalPos + new Vector3(-Mathf.Sin(timer) * deltaX, 0, -Mathf.Sin(timer) * deltaY);
        }
    }

    void HandleGrabbing()
    {
        transform.position = target.transform.position;
        currentGrabbing = true;
    }
}
